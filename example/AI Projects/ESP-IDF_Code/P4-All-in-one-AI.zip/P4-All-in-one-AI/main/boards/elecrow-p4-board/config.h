#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

// ========== Board Configuration ==========
// Peripheral circuit power management (LDO channel)
#define PERIPHERAL_PHY_PWR_LDO_CHAN       (4)        // LDO channel number
#define PERIPHERAL_PHY_PWR_LDO_VOLTAGE_MV (3300)     // Voltage (millivolts)

// I2C configuration
#define PERIPHERAL_I2C_PORT          I2C_NUM_0    // I2C port number
#define PERIPHERAL_I2C_SCL_PIN       GPIO_NUM_19  // Peripheral chip I2C SCL pin
#define PERIPHERAL_I2C_SDA_PIN       GPIO_NUM_18  // Peripheral chip I2C SDA pin

// ========== Audio Configuration ==========
#define AUDIO_INPUT_SAMPLE_RATE  16000
#define AUDIO_OUTPUT_SAMPLE_RATE 16000

// Power amplifier enable pin
#define AUDIO_CODEC_PA_PIN      GPIO_NUM_6  // Power amplifier enable pin (CTRL)

// I2S audio pins
#define AUDIO_I2S_GPIO_MCLK     GPIO_NUM_NC // Master clock pin (unused, set to NC)
#define AUDIO_I2S_SPK_GPIO_LRCK GPIO_NUM_21 // Word select pin (LRCLK, left/right channel)
#define AUDIO_I2S_SPK_GPIO_BCLK GPIO_NUM_22 // Bit clock pin (BCLK)
#define AUDIO_I2S_SPK_GPIO_DOUT GPIO_NUM_23 // Data output pin (SDATA, speaker)

// PDM microphone pins
#define AUDIO_PDM_MIC_GPIO_CLK  GPIO_NUM_3  // PDM microphone clock pin (CLK)
#define AUDIO_PDM_MIC_GPIO_DIN  GPIO_NUM_4  // PDM microphone data input pin (SDIN2)

// ========== Button Configuration ==========
#define BOOT_BUTTON_GPIO        GPIO_NUM_35

// ========== Touch Screen Configuration ==========
// GT911 touch screen pins
#define TOUCH_GPIO_RST          GPIO_NUM_40  // Touch screen reset pin
#define TOUCH_GPIO_INT          GPIO_NUM_39  // Touch screen interrupt pin

// ========== Camera Configuration ==========
// Camera chip SC2336 i2c pins
#define CAMERA_I2C_PORT         I2C_NUM_1    // I2C port number
#define CAMERA_I2C_SCL_PIN      GPIO_NUM_46  // Camera I2C SCL pin
#define CAMERA_I2C_SDA_PIN      GPIO_NUM_45  // Camera I2C SDA pin

// ========== Display Configuration ==========
#define DISPLAY_WIDTH           1024
#define DISPLAY_HEIGHT          600

#define LCD_BIT_PER_PIXEL       (16)
#define PIN_NUM_LCD_RST         GPIO_NUM_5  // LCD reset pin (use NC if not available)

// MIPI DSI configuration (if using MIPI DSI display)
#define DELAY_TIME_MS           (3000)
#define LCD_MIPI_DSI_LANE_NUM   (2)     // DSI data lane number (usually 2 or 4)

// MIPI DSI power management (LDO channel)
#define MIPI_DSI_PHY_PWR_LDO_CHAN       (3)     // LDO channel number
#define MIPI_DSI_PHY_PWR_LDO_VOLTAGE_MV (2500)  // Voltage (millivolts)

#define LCD_GPIO_UPDN           GPIO_NUM_32     // LCD UPDN GPIO
#define LCD_GPIO_SHLR           GPIO_NUM_33     // LCD SHLR GPIO

// Display orientation configuration
#define DISPLAY_SWAP_XY         false   // Whether to swap XY axes
#define DISPLAY_MIRROR_X        false   // X-axis mirror
#define DISPLAY_MIRROR_Y        false   // Y-axis mirror
#define DISPLAY_OFFSET_X        0       // X offset
#define DISPLAY_OFFSET_Y        0       // Y offset

#define DISPLAY_BACKLIGHT_PIN           GPIO_NUM_20
#define DISPLAY_BACKLIGHT_OUTPUT_INVERT false

#endif // _BOARD_CONFIG_H_
